import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireBusiness } from "@/lib/auth/guards";
import { createRepo, forecastInputFor } from "@/lib/data/repo";
import { analyzeOrder, forecast, formatRand, formatShortDate, todayInJohannesburg } from "@/lib/engine";
import { CashChart } from "@/components/CashChart";
import { VerdictBadge } from "@/components/Verdict";
import { computeImpact } from "@/lib/data/insights";
import { DEMO_IDS, isDemoRecord } from "@/lib/demo/demo-data";
import { CountUp } from "@/components/CountUp";
import { AutoTourButton } from "@/components/AutoTour";
import { onboardingComplete, onboardingSteps } from "@/lib/data/onboarding";
import { demoLogin } from "@/app/actions/auth";
import { SubmitButton } from "@/components/SubmitButton";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const { user, business } = await requireBusiness();
  const today = todayInJohannesburg();
  const ctx = await createRepo(prisma).loadContext(business, today);
  const outlook = forecast(forecastInputFor(ctx, null));
  const series30 = outlook.series.slice(0, 31);
  const upcoming = outlook.events.filter((e) => e.date <= series30[series30.length - 1].date).slice(0, 6);

  const drafts = ctx.orders.filter((o) => o.status === "DRAFT");
  const pending = drafts.map((o) => {
    try {
      return { order: o, verdict: analyzeOrder(forecastInputFor(ctx, o)).primary.verdict };
    } catch {
      return { order: o, verdict: null };
    }
  });
  const accepted = ctx.orders.filter((o) => o.status === "ACCEPTED");
  const customerName = (id: string) => ctx.customers.find((c) => c.id === id)?.name ?? "";
  const impact = computeImpact(ctx);
  const steps = onboardingSteps(ctx);
  const showChecklist = !user.isDemo && !onboardingComplete(steps);
  const nextStep = steps.find((st) => !st.done);
  const demoWedding = user.isDemo ? drafts.find((o) => isDemoRecord(o.id, DEMO_IDS.wedding)) : undefined;
  const showTour = !!demoWedding;

  // Orders customers placed through Chrono (already checked when they ordered).
  const viaChrono = new Set(
    (await prisma.order.findMany({ where: { businessId: business.id, source: "CHRONO" }, select: { id: true } })).map((o) => o.id),
  );

  return (
    <main className="layout-2">
      {showTour && (
        <div className="demo-entry demo-entry-top">
          <AutoTourButton />
          <form action={demoLogin}>
            <SubmitButton className="btn btn-wide" pendingLabel="Opening the demo">
              Try the demo
            </SubmitButton>
          </form>
        </div>
      )}
      <div className="col-main">
      <section className="hero-card" data-tour="home-hero">
        <div className="hero-top">
          <span className="muted small">{business.name}</span>
        </div>
        <p className="big-number" style={{ margin: "0.9rem 0 0.2rem" }}>
          <CountUp cents={outlook.startingBalanceCents} />
        </p>
        <p className="muted small" style={{ margin: 0 }}>
          Cash on hand today
        </p>
        <div style={{ margin: "0.9rem -0.25rem 0" }}>
          <CashChart id="hero" series={series30} bufferCents={business.safetyBufferCents} compact onDark />
        </div>
        <p className="small" style={{ margin: "0.4rem 0 0.4rem", color: "rgba(238,246,245,0.8)" }}>
          Lowest in the next 30 days: <strong className="num">{formatRand(outlook.minBalanceCents)}</strong> on {formatShortDate(outlook.minBalanceDate)}
        </p>
      </section>

      <section className="panel">
        <p className="label" style={{ marginTop: 0 }}>
          Your next 30 days, day by day
        </p>
        <CashChart id="home" series={series30} bufferCents={business.safetyBufferCents} />
        <p className="small muted" style={{ marginBottom: 0 }}>
          With the orders you&apos;ve accepted and your regular payments, your lowest point is{" "}
          <strong className="num">{formatRand(outlook.minBalanceCents)}</strong> on {formatShortDate(outlook.minBalanceDate)}.
        </p>
      </section>

      </div>
      <div className="col-side">
      {showChecklist && (
        <section className="panel checklist">
          <p className="label" style={{ margin: 0 }}>
            Get set up
          </p>
          <p className="small muted" style={{ margin: "0.15rem 0 0.75rem" }}>
            {steps.filter((st) => st.done).length} of {steps.length} done. Each step makes your forecasts more accurate.
          </p>
          <div className="progress" aria-hidden="true">
            <span style={{ width: `${(steps.filter((st) => st.done).length / steps.length) * 100}%` }} />
          </div>
          <ol className="list-plain" style={{ marginTop: "0.9rem" }}>
            {steps.map((st) => (
              <li key={st.key} className="check-item" data-done={st.done} data-next={st === nextStep}>
                <span className="tick" aria-hidden="true">
                  {st.done ? "✓" : ""}
                </span>
                <span>
                  {st.done || st.key === "record" ? <strong>{st.title}</strong> : <Link href={st.href}><strong>{st.title}</strong></Link>}
                  <br />
                  <span className="small muted">{st.detail}</span>
                </span>
              </li>
            ))}
          </ol>
        </section>
      )}

      {impact.shortfallsSpotted > 0 && (
        <p className="impact">
          <span className="impact-ring num">{impact.shortfallsSpotted}</span>
          <span className="small">
            cash shortfall{impact.shortfallsSpotted === 1 ? "" : "s"} spotted before you said yes, worth{" "}
            <strong className="num">{formatRand(impact.cashAtRiskCents)}</strong>
          </span>
        </p>
      )}


      <h2 className="h2">Orders waiting for your decision</h2>
      {pending.length === 0 ? (
        <p className="muted">No orders waiting. When a customer asks for something, check it here before you say yes.</p>
      ) : (
        <div data-tour="home-waiting" className="panel rows" style={{ paddingTop: 0, paddingBottom: 0 }}>
          {pending.map(({ order, verdict }) => (
            <Link key={order.id} href={`/orders/${order.id}`} className="row" data-tour={demoWedding && order.id === demoWedding.id ? "wedding" : viaChrono.has(order.id) ? "chrono-order" : undefined}>
              <span>
                <strong>{order.title}</strong>
                <br />
                <span className="small muted">
                  {customerName(order.customerId)}, <span className="num">{formatRand(order.valueCents)}</span>
                </span>
                {viaChrono.has(order.id) && (
                  <>
                    <br />
                    <span className="chip-chrono">via Chrono</span>
                  </>
                )}
              </span>
              {verdict && <VerdictBadge verdict={verdict} />}
            </Link>
          ))}
        </div>
      )}

      {accepted.length > 0 && (
        <>
          <h2 className="h2">Accepted orders</h2>
          <div data-tour="home-accepted" className="panel rows" style={{ paddingTop: 0, paddingBottom: 0 }}>
            {accepted.map((o) => (
              <Link key={o.id} href={`/orders/${o.id}`} className="row">
                <span>
                  {o.title}
                  <br />
                  <span className="small muted">{customerName(o.customerId)}</span>
                </span>
                <span className="num">{formatRand(o.valueCents)}</span>
              </Link>
            ))}
          </div>
        </>
      )}
      <h2 className="h2">Coming up</h2>
      {upcoming.length === 0 ? (
        <p className="muted">Nothing due in the next 30 days.</p>
      ) : (
        <div data-tour="home-coming" className="panel rows" style={{ paddingTop: 0, paddingBottom: 0 }}>
          {upcoming.map((e) => (
            <div key={`${e.refId}-${e.date}`} className="row">
              <span>
                {e.label}
                <br />
                <span className="small muted">{formatShortDate(e.date)}</span>
              </span>
              <strong className="num" style={{ color: e.direction === "IN" ? "var(--safe)" : "var(--ink)" }}>
                {e.direction === "IN" ? "+" : "−"}
                {formatRand(e.amountCents)}
              </strong>
            </div>
          ))}
        </div>
      )}

      </div>
    </main>
  );
}
